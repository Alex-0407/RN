/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    Platform,
    ListView,
    TouchableHighlight,
    ActivityIndicator,
    View,
    Image
} from 'react-native';

import Dimensions from 'Dimensions';

import Icon from 'react-native-vector-icons/Ionicons';
import Mock from 'mockjs';
import config from '../common/config';
import request from '../common/request';


const {width,height} = Dimensions.get('window');


let cachedResults={
    nextPage:1,
    items:[],
    total:0,
}

export default class List extends Component {

    constructor(props) {
        super(props);//这一句不能省略，照抄即可
        this.state = {
            dataSource:new ListView.DataSource({
                rowHasChanged:(row1,row2)=> row1 !== row2,
            }),
            isLoadingTail:false,
        };
    }

    componentWillMount() {
        this.dsfetchData();//打底数据共3条
    }

    componentDidMount(){
        this._fetchData(1);//从服务器获取的真实数据
    }


//http://rap.taobao.org/mockjs/7756/api/list?accessToken=ssss
    _fetchData(page){

        this.setState({
            isLoadingTail:true
        });

        console.log('封装后的异步请求网络get');

        request.get(config.api.base+ config.api.list,{
            accessToken:'jjjj',
            page:page
        }).then(
            (data)=>{

                if(data.success){
                    //把服务器得到的数据存到缓存里面
                    let items = cachedResults.items.slice();
                    items = items.concat(data.data);
                    cachedResults.items = items
                    cachedResults.total = data.total

                    console.log('总个数据的长度是：'+cachedResults.total);
                    console.log('当前的listview数据的总长度是：'+cachedResults.items.length);


                    setTimeout(()=>{

                        this.setState({
                            dataSource:this.state.dataSource.cloneWithRows(
                                cachedResults.items
                            ),
                            isLoadingTail:false
                        });

                    },2000);



                }

            }

        ).catch(
            (err) => {
                this.setState({
                    isLoadingTail:false
                });
                console.log('err' + err);
            }
        )
    }

    _fetchData2(){

        //网络当中去请求数据  fetch   xmlhttprequest websocket
        console.log('GET访问网络');
        let url = 'http://rap.taobao.org/mockjs/7756/api/list?accessToken=ssss';
        fetch(url).then(
            (response) => {
                console.log('第一个then里面');
                return response.json()
            }
        ).then(
            (response) => {
                //这里不能用console否则看不到 这是一个巨大的坑 用alert一点问题没有
                // alert('服务器返回：' + responseText);
                let result= JSON.stringify(response);
                // throw new Error('sssss');
                // console.log('服务器返回：' + result);
                let result1=Mock.mock(response);
                //canvas node找不到 安装 完了 之后  其他的问题出现

                if(result1.success){
                    this.setState({
                        dataSource:this.state.dataSource.cloneWithRows(
                            result1.data
                        ),
                    });
                }


            }
        ).catch(
            (err) => {
                console.log('err' + err);
            }
        );


    }



    dsfetchData(){
        // let result = Mock.mock({"data|20":[{"_id":"@ID","video":"http:\/\/v.youku.com\/v_show\/id_XMTczMDM0NzQ2OA==.html?f=26378220&spm=a2hww.20023042.m_223465.5~5~5~5!2~5~5~A.BZYRBN&from=y1.3-idx-beta-1519-23042.223465.4-1","thumb":"@IMG(1280x720,@color())","title":"@cparagraph(1, 3)"}],"total":20,"success":true});


        this.setState({
            dataSource: this.state.dataSource.cloneWithRows(

                // result.data

                [
                    {
                        "_id":"450000201111076177","thumb":"http://dummyimage.com/1280x720/a99343)","title":"@cparagraph(1, 3)","video":"http://v.youku.com/v_show/id_XMTczMDM0NzQ2OA==.html?f=26378220&spm=a2hww.20023042.m_223465.5~5~5~5!2~5~5~A.BZYRBN&from=y1.3-idx-beta-1519-23042.223465.4-1"
                    }
                    ,
                    {
                        "_id":"410000201207096642","thumb":"http://dummyimage.com/1280x720/afebb9)","title":"@cparagraph(1, 3)","video":"http://v.youku.com/v_show/id_XMTczMDM0NzQ2OA==.html?f=26378220&spm=a2hww.20023042.m_223465.5~5~5~5!2~5~5~A.BZYRBN&from=y1.3-idx-beta-1519-23042.223465.4-1"
                    }
                    ,
                    {
                        "_id":"210000201211100360","thumb":"http://dummyimage.com/1280x720/4564d3)","title":"@cparagraph(1, 3)","video":"http://v.youku.com/v_show/id_XMTczMDM0NzQ2OA==.html?f=26378220&spm=a2hww.20023042.m_223465.5~5~5~5!2~5~5~A.BZYRBN&from=y1.3-idx-beta-1519-23042.223465.4-1"
                    }
                ]

            ),
        });
    }

    //加载更多的数据 上拉加载更多  滑动分页
    _fetchMoreData=()=>{

        if(!this._hasMore() || this.state.isLoadingTail){
            return
        }

        //去服务器请求加载更多的数据了

        let page=  cachedResults.nextPage;

        this._fetchData(page)

    }

    _renderFooter=()=>{
        if(!this._hasMore() && cachedResults.total!== 0 ){
            return (<View style={styles.loadingMore}>
                <Text style={styles.loadingText}>没有更多数据啦...</Text>
            </View>);
        }

        if(!this.state.isLoadingTail){
            return <View style={styles.loadingMore}/>
        }

        return (

            <ActivityIndicator
            style={styles.loadingMore}
            />

        );
    }

    _hasMore(){
        return cachedResults.items.length !== cachedResults.total
    }

    render() {
        return (
            <View style={styles.container}>


                <View style={styles.header}>
                  <Text style={styles.headerText}>
                    视频列表
                  </Text>

                </View>


                <ListView
                    dataSource={this.state.dataSource}
                    renderRow={this._renderRow}
                    enableEmptySections={true}
                    automaticallyAdjustContentInsets={false}
                    onEndReached={this._fetchMoreData}
                    onEndReachedThreshold={20}
                    renderFooter={this._renderFooter}

                    showsVerticalScrollIndicator={false}

                    style={styles.listView}
                />




            </View>
        );
    }

    _renderRow=(rowData)=>{
        return (

            <TouchableHighlight>


                <View style={styles.item}>

                <Text style={styles.title}>{rowData.title}</Text>

                <Image style={styles.thumb} source={{uri:rowData.thumb}}>

                    <Icon
                        name='ios-play'
                        size={28}
                        style={styles.play} />


                </Image>

                    <View style={styles.itemFooter}>

                        <View style={styles.handleBox}>

                            <Icon
                                name='ios-heart-outline'
                                size={28}
                                style={styles.up} />

                            <Text style={styles.handleText}>点赞</Text>


                        </View>


                        <View style={styles.handleBox}>

                            <Icon
                                name='ios-chatbubbles'
                                size={28}
                                style={styles.commentIcon} />

                            <Text style={styles.handleText}>评论</Text>


                        </View>




                    </View>






                </View>



            </TouchableHighlight>




        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5FCFF',
    },
    welcome: {
        fontSize: 20,
        textAlign: 'center',
        margin: 10,
    },
    header:{
        marginTop:Platform.OS === 'ios' ? 20 : 0,
        paddingTop:25,
        paddingBottom:12,
        backgroundColor:'#ee735c',

    },
    headerText:{
        fontSize:16,
        fontWeight:'600',
        textAlign:'center',
        color:'#fff',
    },

    listView: {
        paddingTop: 20,
        backgroundColor: 'white',
    },

    item:{
        width:width,
        marginBottom:10,
        backgroundColor:'white'
    },


    title:{
        fontSize:18,
        padding:10,
        color:'#333'
    },

    thumb:{
        width:width,
        height:width*0.56,
        resizeMode:'cover'
    },

    play:{
        position:'absolute',
        bottom:14,
        right:14,
        width:46,
        height:46,
        paddingTop:9,
        paddingLeft:18,
        backgroundColor:'transparent',
        borderColor:'#000',
        borderWidth:1,
        borderRadius:23,
        color:'#ed7b66'
    },


    itemFooter:{
        flexDirection:'row',
        justifyContent:'space-between',
        backgroundColor:'#eee'
    },

    handleBox:{
        padding:10,
        flexDirection:'row',
        width: width/2 - 0.5,
        justifyContent:'center',
        backgroundColor:'white',
    },


    up:{

        fontSize:22,
        color:'#333'
    },

    commentIcon:{
        fontSize:22,
        color:'#333'
    },



    handleText:{
        fontSize:18,
        color:'#333',
        paddingLeft:12,
    },


    loadingMore:{

        marginVertical:20
    },


    loadingText:{
        fontSize:18,
        color:'red',
        textAlign:'center'
    },









});

