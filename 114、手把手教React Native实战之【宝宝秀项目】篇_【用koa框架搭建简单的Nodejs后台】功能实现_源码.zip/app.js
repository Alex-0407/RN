'use strict'

var koa = require('koa');
var logger = require('koa-logger');
var session = require('koa-session');
var bodyParser = require('koa-bodyparser');


//生成服务器的一个实例
var app = koa();

app.keys=['mybabay']

app.use(logger())
app.use(session(app))
app.use(bodyParser())

//实际在项目中 并不推荐使用这种方式  单独的建立路由文件
// app.use(function *(next) {
//     console.log(this.href);
//     console.log(this.method);
//
//     this.body={
//         success:true
//     }
//
//     yield next
// });

var router = require('./config/routes')();

app
    .use(router.routes())
    .use(router.allowedMethods())



app.listen(6789);
console.log('服务器正在监听端口号为：6789');

