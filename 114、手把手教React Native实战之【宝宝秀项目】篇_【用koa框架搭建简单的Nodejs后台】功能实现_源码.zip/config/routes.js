'use strict'

var Router =  require('koa-router');
var User = require('../app/constrollers/user');
var App  = require('../app/constrollers/app');


module.exports  = function () {
    var router = new Router({
        prefix:'/api/1'
    })

    //设置一些路由的规则
    router.post('/u/signup',User.signup);
    router.post('/u/verify',User.verify);
    router.post('/u/update',User.update);
    router.post('/signature',App.signature);

    return router;


}