'use strict'

exports.signup  = function *(next) {
    this.body={
        success:true
    }
}

exports.update  = function *(next) {
    this.body={
        success:true
    }
}


exports.verify  = function *(next) {
    this.body={
        success:true
    }
}